# DOI Reserved Note — A6-CTP v0.1.4

**Reserved Zenodo DOI:** `10.5281/zenodo.21227129`  
**Package:** `A6_CTP_v0_1_4_Zenodo_10_5281_zenodo_21227129`  
**Date:** 2026-07-06

This note binds the reserved Zenodo DOI to the reviewed v0.1.4 package without modifying the reviewed Markdown/PDF artifact after b-layer review closure.

The reviewed artifact contains:

```text
Parent DOI: TBD: insert parent A6 DOI before publication
```

That field refers to the separate parent A6 v0.1 DOI-published artifact. It is not the DOI of this addendum deposit.

The DOI for this addendum deposit is recorded in package metadata:

```text
10.5281/zenodo.21227129
```

This sidecar avoids invalidating the frozen reviewed artifact hashes while still giving Zenodo and citation metadata the reserved DOI before publication.
