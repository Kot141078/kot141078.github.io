# Suggested Zenodo Form Values — A6-CTP v0.1.4

Use these values for the Zenodo web form if helpful.

## DOI

- Do you already have a DOI for this upload? No, I need one.
- Reserved DOI: `10.5281/zenodo.21227129`

## Resource type

- Publication
- Technical note

## Title

A6 Composition Transition Predicate Addendum v0.1.4: EXIT / SPLIT / HOLD / DISSOLVE classification under governed binding

## Publication date

2026-07-06

## Authors / Creators

- Kotov Ivan
- ORCID: 0009-0009-6002-9845
- Affiliation: Independent researcher

## Description

Bounded addendum defining the A6 composition transition predicate for EXIT, SPLIT, HOLD, and DISSOLVE classification under governed binding. The addendum clarifies how an A6 composition transition is classified by preservation or loss of a unique lawful successor, resolved incompatible successor claims, HOLD/FREEZE handling for unresolved predicates, and witnessed successor-space exhaustion for DISSOLVE.

This Zenodo package includes the reviewed Markdown source, academic PDF, b-layer review records, and hash-verification records. Status: draft bounded addendum; non-replacement companion to the parent A6 v0.1 artifact; not deployment-ready; no conformance claim; not legal advice; not product certification.

## Keywords

A6; c=a+b; governed binding; composition transition; EXIT; SPLIT; HOLD; DISSOLVE; unique lawful successor; witness; ARL; CGAM; continuity; AI governance

## License

Creative Commons Attribution 4.0 International (CC BY 4.0)

## Version

v0.1.4
