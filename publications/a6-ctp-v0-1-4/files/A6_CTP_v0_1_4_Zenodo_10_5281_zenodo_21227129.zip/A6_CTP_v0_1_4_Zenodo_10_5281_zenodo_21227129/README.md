# A6 Composition Transition Predicate Addendum v0.1.4

**Reserved Zenodo DOI:** `10.5281/zenodo.21227129`  
**Version:** `v0.1.4`  
**Author:** Kotov Ivan  
**Date:** 2026-07-06  
**Location:** Bruxelles, Belgium

This package contains the frozen reviewed A6 Composition Transition Predicate Addendum v0.1.4 and its associated b-layer review and hash-verification records.

The addendum defines the EXIT / SPLIT / HOLD / DISSOLVE transition predicate for A6 composition under governed binding. Its core threshold is unique lawful continuation: EXIT requires exactly one lawful successor; SPLIT requires resolved incompatible successor claims; HOLD preserves unresolved classification state; DISSOLVE requires witnessed successor-space exhaustion.

## Status

- Bounded addendum / transition-predicate clarification.
- Non-replacement companion to the parent A6 v0.1 DOI-published artifact.
- Draft-level predicate-review cycle: closed as convergent by b-layer review record b4.
- Not deployment-ready.
- No conformance claim.
- Not legal advice, not product certification, not a legal dissolution or arbitration procedure.

## Important DOI note

The DOI `10.5281/zenodo.21227129` was reserved for this Zenodo deposit before upload. The reviewed Markdown/PDF artifact itself is not rewritten after b-layer review closure. The artifact header still contains `Parent DOI: TBD` because that field refers to the separate parent A6 v0.1 DOI artifact, not this addendum deposit.

The reserved DOI is bound at the package metadata level through:

- `.zenodo.json`
- `CITATION.cff`
- `metadata/DOI_RESERVED_NOTE_A6_CTP_v0_1_4.md`
- this `README.md`

## Contents

```text
artifact/
  A6_Composition_Transition_Predicate_Addendum_v0_1_4.md
  A6_Composition_Transition_Predicate_Addendum_v0_1_4_academic.pdf
  SHA256SUMS_A6_CTP_v0_1_4.txt

review/
  A6-CTP_v0_1_1_b_layer_review_record.md
  A6-CTP_v0_1_2_b_layer_review_record.md
  A6-CTP_v0_1_3_b_layer_review_record.md
  A6-CTP_v0_1_4_b_layer_review_record.md
  A6-CTP_v0_1_4_integration_hash_verification_record.md
  SHA256SUMS_A6_CTP_v0_1_4_REVIEW_RECORDS.txt

metadata/
  DOI_RESERVED_NOTE_A6_CTP_v0_1_4.md
  ZENODO_FORM_VALUES_A6_CTP_v0_1_4.md

CITATION.cff
.zenodo.json
LICENSE-DOCS-CC-BY-4.0.md
MANIFEST_A6_CTP_v0_1_4_ZENODO.json
SHA256SUMS_A6_CTP_v0_1_4_ZENODO_PACKAGE.txt
README.md
```

## Verification

Run these commands after extracting the ZIP. The artifact-level and review-level checksum files are intentionally scoped to their own folders; the package-level checksum runs from the package root.

```bash
cd A6_CTP_v0_1_4_Zenodo_10_5281_zenodo_21227129
( cd artifact && sha256sum -c SHA256SUMS_A6_CTP_v0_1_4.txt )
( cd review && sha256sum -c SHA256SUMS_A6_CTP_v0_1_4_REVIEW_RECORDS.txt )
sha256sum -c SHA256SUMS_A6_CTP_v0_1_4_ZENODO_PACKAGE.txt
```

The package-level checksum file uses relative paths for portable verification.

## Suggested citation

Kotov, Ivan. *A6 Composition Transition Predicate Addendum v0.1.4*. Zenodo. `10.5281/zenodo.21227129`.
